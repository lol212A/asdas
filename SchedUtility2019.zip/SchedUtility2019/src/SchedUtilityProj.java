import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;
import java.util.TreeSet;

public class SchedUtilityProj {

	private static String grid[][];
	private static int lastRow = -1;
	private static final int lastCol = 14;
	private static TreeMap<String, Teacher> teachers;

	public static void main(String[] args) {

		loadNorthShedules();
		testLoadNorthShedules();
		// testCreateTeacherMap();
	}

	public static void testCreateTeacherMap() {
		createTeacherMap();
		int k = 0;
		for (String key : teachers.keySet()) {
			k++;
			if (k > 75 && k < 105) {
				System.out.println(teachers.get(key));
				System.out.println("~~~~~~~~~~~~~\n~~~~~~~~~~~~~");

			}
		}
	}

	public static void testLoadNorthShedules() {
		int rows[] = { 314, 2080, 4657 };
		for (int r : rows) {
			for (int j = 0; j < lastCol; j++) {
				System.out.print(grid[r][j] + ",");
			}
			System.out.println(grid[r][lastCol]);
		}
		System.out.println("lastRow is " + lastRow);

		// output should be the following:
		// 44298,M,DARION,BARNIE,SCHLACK,MICHELLE,BARDAR1@nilesx12.orq,10,7,IT1A07,Advance
		// App Development,2070,Ruth,David,"M,T,W,R,F"
		// 23349,F,RICKY,EMMA,SWEDBERG,ANDREW
		// W,EMMRIC1@nilesx12.orq,12,6,MI1L02,LUNCH,CAFE,,,"M,W"
		// 24291,F,ZACHARY,VELVA,SWEDBERG,ANDREW
		// W,VELZAC1@nilesx12.orq,12,2,SHSP00,Study Hall Par,AUD,STAFF,Study Halls/
		// Lunch/ Early Release,F
		// lastRow is 23042

	}

	/**
	 * Using EasyReader, load all the comma separated values in NorthSchedules.txt
	 * into 2D array grid. Assign the appropriate value to lastRow.
	 * 
	 * Check your code by looking at the results of testLoadNorthSchedules
	 */
	public static void loadNorthShedules() {
		grid = new String[30000][15];
		EasyReader infile = new EasyReader("NorthSchedules.txt");
		if (infile.bad()) {
			System.err.println("ERROR: file " + "NorthSchedules.txt" + " could not be read");
			return;
		}
		String line = infile.readLine();
		int lineNumber = 1;
		while (line != null && line.length() > 0) {
			String tokens[] = line.split(",");
			for (int j = 0; j < 15; j++) {
				grid[lineNumber][j] = tokens[j];
			}
			lineNumber++;
			if (lineNumber > 24000) {
				break;
			}
			line = infile.readLine();
		}
		infile.close();
		lastRow = 23042;
	}

	/**
	 * Initialize instance variable teachers and fill it with every Teacher in the
	 * schedule so that each Teacher has their respective Students added
	 * appropriately
	 */
	/**
	 * This method is for reference as an example of how to use EasyReader
	 * 
	 * @param fileName
	 */
	public void readFileLineByLine(String fileName) {
		EasyReader infile = new EasyReader(fileName);
		if (infile.bad()) {
			System.err.println("ERROR: file " + fileName + " could not be read");
			return;
		}
		String line = infile.readLine();
		int lineNumber = 1;
		// presuming data file has no blank lines, except at the end
		while (line != null && line.length() > 0) {
			System.out.println(line);
			lineNumber++;
			if (lineNumber > 5) {
				// you may choose a number arbitrarily larger than
				// the predicted number of lines in the file
				// to avoid an infinite loop..
				//
				// ESPECIALLY important when writing to a file
				break;
			}
			line = infile.readLine();
		}
		infile.close();
	}

	/**
	 * This method is for reference as an example of how to use EasyWriter
	 * 
	 * @param fileName
	 */
	public void sampleWriteToFile(String fileName) {
		EasyWriter outfile = new EasyWriter(fileName); // truncates the file and writes at the beginning
		// EasyWriter outfile = new EasyWriter(fileName,"app"); // appends text and
		// writes at the end
		if (outfile.bad()) {
			System.err.println("ERROR: file " + fileName + " could not be written");
			return;
		}
		int lineNumber = 1;
		String line = "this is line: " + lineNumber;
		while (true) {
			line = "this is line: " + lineNumber;
			System.out.println(line);
			outfile.println(line);
			lineNumber++;
			if (lineNumber > 5) {
				// you may choose a number arbitrarily larger than
				// the predicted number of lines to be written
				// to avoid an infinite loop..
				//
				// ESPECIALLY important when writing to a file
				break;
			}
		}
		outfile.close();
	}
	
	 public static void createTeacherMap() {
		 String tchr = grid[i][12] + grid[i][13];
		 if (teachers.containsKey(tchr)) {
			 Student std = new Student();
			 teachers.get(tchr).addStudent(course, std);
		 }
		 else {
			 new Teacher = Teacher (t);
			 teachers.put(tchr, t);
		 }
	 }

}
