public class Student implements Comparable {
	private String firstName, lastName, idNum, emailAddr;

	public Student(String fn, String ln, String idn, String ema) {
		firstName = fn;
		lastName = ln;
		idNum = idn;
		emailAddr = ema;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdNum() {
		return idNum;
	}

	public void setIdNum(String idNum) {
		this.idNum = idNum;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Student implements CompareTo(Object o) {
		
        Student s = (Student) o;
		
		if ((lastName + firstName + idNum + emailAddr).equals(s.lastName + s.firstName +  s.idNum + s.emailAddr)) {
			return true;
		} 
	}

	public String toString() {
		return firstName + "," + lastName + "," + idNum + "," + emailAddr;
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
