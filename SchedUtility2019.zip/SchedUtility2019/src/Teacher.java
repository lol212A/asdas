
import java.util.TreeMap;
import java.util.TreeSet;

public class Teacher implements Comparable {
	private String firstName, lastName, emailAddr;
	private TreeMap<String, TreeSet<Student>> courses;

	public Teacher(String fn, String ln, Object o) {
		Teacher t = (Teacher) o;
		firstName = fn;
		lastName = ln;
		emailAddr = ln.substring(0, 4) + fn.substring(0, 4) + " " + emailAddr;
	}

	public boolean equals(Object other) {
		Teacher t = (Teacher) other;
		if ((firstName + lastName).equals(t.firstName + t.lastName)) {
			return true;
		} else {
			return false;
		}
	}

	public String toString() {
		String str = "";
		for (String crs : courses.keySet()) {
			str = crs + "\n";
			for (Student s : courses.get(crs)) {
				str += s.toString();
			}
		}
		return str;
	}

	public void addStudent(String course, Student std) {
		if (!(courses.containsKey(course))) {
			TreeSet<Student> courses1 = new TreeSet<Student>();
			courses1.add(std);
			courses.put(course, courses1);
		}
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
